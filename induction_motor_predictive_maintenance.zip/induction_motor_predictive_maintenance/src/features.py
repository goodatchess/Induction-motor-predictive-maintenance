import numpy as np
import pandas as pd
from scipy.stats import kurtosis


def signal_features(x, prefix):
    x = np.asarray(x, dtype=float).ravel()
    return {
        f"{prefix}_rms": float(np.sqrt(np.mean(x ** 2))),
        f"{prefix}_variance": float(np.var(x)),
        f"{prefix}_peak_to_peak": float(np.ptp(x)),
        f"{prefix}_kurtosis": float(np.nan_to_num(
            kurtosis(x, fisher=False, bias=False)
        )),
    }


def sample_features(current_window, vibration_window):
    current_window = np.asarray(current_window, dtype=float)
    vibration_window = np.asarray(vibration_window, dtype=float).squeeze()

    if current_window.ndim == 1:
        current_window = current_window[:, None]

    features = {}
    for channel in range(current_window.shape[1]):
        features.update(
            signal_features(current_window[:, channel], f"current_{channel+1}")
        )

    features.update(signal_features(vibration_window, "vibration"))
    return features


def build_feature_table(current, vibration, labels):
    current = np.asarray(current)
    vibration = np.asarray(vibration)
    labels = np.asarray(labels).ravel()

    if current.ndim == 2:
        current = current[:, :, None]

    if vibration.ndim == 3 and vibration.shape[-1] == 1:
        vibration = vibration[:, :, 0]

    if not (len(current) == len(vibration) == len(labels)):
        raise ValueError("Current, vibration and labels must have equal sample counts.")

    rows = [
        sample_features(current[i], vibration[i])
        for i in range(len(labels))
    ]

    df = pd.DataFrame(rows)
    df["label"] = labels.astype(str)
    return df
